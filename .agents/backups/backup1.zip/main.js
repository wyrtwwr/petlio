document.addEventListener('DOMContentLoaded', () => {
  console.log('Address Shop loaded');

  const sizeCards = Array.from(document.querySelectorAll('.size-card'));
  const sectionNavLinks = Array.from(document.querySelectorAll('.main-nav a[href^="#"]'));

  function getSizeData(card) {
    if (!card) {
      return null;
    }

    return {
      key: card.dataset.size || '',
      title: card.dataset.sizeTitle || card.querySelector('h3')?.textContent.trim() || '',
      value: card.dataset.sizeValue || card.querySelector('.size-card__size')?.textContent.trim() || '',
      price: card.dataset.sizePrice || card.querySelector('.size-card__price')?.textContent.trim() || '',
      userSelected: true,
    };
  }

  function readOrderData() {
    try {
      return JSON.parse(localStorage.getItem('petlioOrder') || '{}');
    } catch (error) {
      return {};
    }
  }

  function selectSize(selectedCard, shouldSave = true) {
    const previousOrder = readOrderData();
    const nextOrder = {
      ...previousOrder,
      size: getSizeData(selectedCard),
    };

    sizeCards.forEach((item) => {
      const isActive = item === selectedCard;

      item.classList.toggle('is-selected', isActive);
      item.setAttribute('aria-pressed', String(isActive));
    });

    if (shouldSave && nextOrder.size) {
      delete nextOrder.checkoutRequestId;
      localStorage.setItem('petlioOrder', JSON.stringify(nextOrder));
    }
  }

  sizeCards.forEach((card) => {
    card.addEventListener('click', (event) => {
      if (event.target.closest('.size-card__wish')) {
        return;
      }

      selectSize(card);
    });

    card.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        selectSize(card);
      }
    });
  });

  const storedSizeKey = readOrderData().size?.userSelected === true
    ? readOrderData().size?.key
    : '';
  const storedSizeCard = sizeCards.find((card) => card.dataset.size === storedSizeKey);

  selectSize(storedSizeCard || null, false);

  if (sectionNavLinks.length) {
    const sections = sectionNavLinks
      .map((link) => document.querySelector(link.getAttribute('href')))
      .filter(Boolean);

    function setActiveNav(id) {
      sectionNavLinks.forEach((link) => {
        link.classList.toggle('is-active', link.getAttribute('href') === `#${id}`);
      });
    }

    const observer = new IntersectionObserver((entries) => {
      const visibleEntry = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

      if (visibleEntry) {
        setActiveNav(visibleEntry.target.id);
      }
    }, {
      rootMargin: '-25% 0px -55% 0px',
      threshold: [0.1, 0.35, 0.6],
    });

    sections.forEach((section) => observer.observe(section));
    setActiveNav(window.location.hash.replace('#', '') || sections[0]?.id);
  }
});
